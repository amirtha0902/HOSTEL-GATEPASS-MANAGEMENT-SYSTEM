
<?php
include('Header.php');
?>
	
	<br/>
	<center><h4>ADMIN LOGIN</h4></center>

	<form action="LoginCode.php" method="post">
		<table class="tbl" align="center" class="login-style">
			<tr>
				<td>
					<img src="Image/login1.jpg" style="max-width:180px;" />
				</td>
			</tr>
			<tr>
				<td><input type="text" name="txtUsername" placeholder=" USERNAME" Style="width:180px; text-align:center;" Required /></td>
			</tr>
			<tr>
				<td><input type="password" name="txtPassword" placeholder=" PASSCODE" Style="width:180px; text-align:center;" Required/></td>
			</tr>
			<tr>
				<td><br><input type="submit" name="btnSubmit" value="Login" class="btn_submit" Style="width:180px;"/></td>
			</tr>
		</table>
	</form>


</div>
</body>
</html>