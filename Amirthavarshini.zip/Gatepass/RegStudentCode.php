<?php
include('HeaderAdmin.php');
?>

<?php
	include('Db.php');
	
	$RegNo=$_POST["txtId"];
	$Name=$_POST["txtName"];
	$Gender=$_POST["ddGender"];
	$Address=$_POST["txtAddress"];
	$Branch=$_POST["ddDept"];
	$ContactNo=$_POST["txtContactNo"];
	$ParentContactNo=$_POST["txtParentContactNo"];
	$DOB=$_POST["txtDOB"];
	$MailId=$_POST["txtEMailId"];
	$AadhaarNo=$_POST["txtAadhaarNo"];
	$YearOfJoin=$_POST["txtYearOfJoin"];
	$Scholorship=$_POST["txtScholarship"];
	$FirstGraduate=$_POST["ddFirstGraduate"];
	$SSLCRollNo=$_POST["textSSLCRollNo"];
	$SSLCMark=$_POST["textSSLCMark"];
	$SSLCPercentage=$_POST["txtSSLCPercentage"];
	$HSCRollNo=$_POST["textHSCRollNo"];
	$HSCMark=$_POST["textHSCMark"];
	$HSCPercentage=$_POST["txtSSLCPercentage"];
	$Government=$_POST["ddGovernment"];
	$Hosteller=$_POST["ddHosteller"];
	$pass=$_POST["txtPass"];
		
	$qry="Insert Into student Values('". $RegNo ."','". $Name ."','". $Gender ."','". $Address ."','". $Branch ."','". $ContactNo ."','". $ParentContactNo ."','". $DOB ."','". $MailId ."','". $AadhaarNo ."','". $YearOfJoin ."','". $Scholorship ."','". $FirstGraduate ."','". $SSLCRollNo ."','". $SSLCMark ."','". $SSLCPercentage ."','". $HSCRollNo ."','". $HSCMark ."','". $HSCPercentage ."','". $Government ."','". $Hosteller ."','" . $pass . "')";
	mysqli_query($con,$qry) or die(mysqli_error());
	
   	echo "<br/><br/>Student Registraion Successfully!<br/>";
	mysqli_close($con);
?>