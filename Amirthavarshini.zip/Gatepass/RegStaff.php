
<?php
include('HeaderAdmin.php');
include('Db.php');
?>
	
	<br/>

	<div style="width:100%; text-align: center;">

	<h4>STAFF REGISTRATION</h4>

	<form action="RegStaffCode.php" method="post" >
	<center>
		<table style="text-align:center ;width:40%;">
			<tr>
				<td>
					Staff ID.:
					
					</td>
					<td>
					<input type="text" name="txtId" style="width:150px;" Required/>
				</td>
				</tr>
				<tr>
				<td>
					Staff Name:
					</td>
					<td>
					<input type="text" name="txtName" style="width:200px;"Required/>
				</td>
				</tr>
			
			
			<tr> 
				 <td>
				 	Department:
				 </td>
				 <td>
				 	<select  name="ddDept" style="width:200px;" Required>
						<option value="">Select</option>
					  	<option value="CS">CS</option>
					  	<option value="MCA">MCA</option>
					  	<option value="MBA">MBA</option>
					</select> 
				</td>
				</tr>
				<tr> 
				 <td>
				 	Staff Type:
				 </td>
				 <td>
				 	<select  name="ddType" style="width:200px;" Required>
						<option value="">Select</option>
					  	<option value="HOD">HOD</option>
					  	<option value="Others">Others</option>
					  	
					</select> 
				</td>
				</tr>
				<tr>
				<td>Contact No:
				</td>
				<td>
				<input type="text" style="width:200px;" name="txtContactNo" Required pattern='[0-9]{10}'/>
				</td>
				
			</tr>
			<tr>
			
			
				<td>Email ID:</td>
				
				<td><input type="email" style="width:200px;" name="txtEMailId" Required/></td>
				
				 
			</tr>
			<tr>
			
			
				<td>Password:</td>
				
				<td><input type="password" style="width:200px;" name="txtPass" Required/></td>
				
				 
			</tr>
			
			<tr>
				<td colspan="2">
					<br/>
					<input type="submit" name="btnSubmit" value="Submit" class="btn_submit" style="width:500px;" />
				</td>
			</tr>
		</table>
		</center>
	</form>

	</div>


</div>
</body>
</html>