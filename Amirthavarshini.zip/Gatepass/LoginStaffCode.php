<?php
    session_start();
    include('Db.php');
	
	$Username = $_POST["txtSID"];
	$Password = $_POST["txtPassword"];
		$query= mysqli_query($con,"Select Count(*) as data From Stafftable Where StaffID = '". $Username ."' and Password = '". $Password ."' ");
		$row = mysqli_fetch_assoc($query);
		if($row['data']==1){
			$_SESSION["username"] = $Username;
			$_SESSION["staffid"] = $Username;
			$_SESSION["usertype"]="staff";
			$query= mysqli_query($con,"Select Dept From Stafftable Where StaffID = '". $Username ."' and Password = '". $Password ."' ");
			$row = mysqli_fetch_assoc($query);
			$_SESSION["Dept"] =$row['Dept'];
            header('location:HomeStaff.php');
		}
		else{
            echo "Invalid Credentials!<br/>";
           echo "<a href='LoginStaff.php'>Go Back</a>";
		}
	

	mysqli_close($con);
?>