<?php
    session_start();
    include('Db.php');
	
	$Username = $_POST["txtUsername"];
	$Password = $_POST["txtPassword"];
	
	if($Username == "admin")
	
	{
		$query= mysqli_query($con,"Select Count(*) as data From AdminTable Where Username = '". $Username ."' and Password = '". $Password ."'");		
		$row = mysqli_fetch_assoc($query);
		if($row['data']==1){
			$_SESSION["username"] = $Username;
			$_SESSION["usertype"] = $Username;
            header('location:HomeAdmin.php');
		}
		else{
            echo "Invalid Credentials!<br/>";
           echo "<a href='Login.php'>Go Back</a>";
		}
	}
	else 
	{
		$query= mysqli_query($con,"Select Count(*) as data From StudentTable Where RegNo = '". $Username ."' and Password = '". $Password ."' ");
		$row = mysqli_fetch_assoc($query);
		if($row['data']==1){
			$_SESSION["username"]=$Username;
			header('location:HomeAdmin.php');
		}
		else{
            echo "Invalid Credentials!<br/>";
           echo "<a href='Login.php'>Go Back</a>";
		}
	}

	mysqli_close($con);
?>