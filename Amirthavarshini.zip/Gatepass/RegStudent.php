<?php
include('HeaderAdmin.php');
include('Db.php');
?>
		<br/>
	<div style="margin-left: 10%; text-align: center;">

	<h4>STUDENT REGISTRATION</h4>

	<form action="RegStudentCode.php" method="post" >
		<table style="text-align:left;">
			<tr>
				<td>
					Register No.:
					<br/>
					<input type="text" name="txtId" style="width:150px;" Required/>
				</td>
				<td>
					Student Name:
					<br/>
					<input type="text" name="txtName" style="width:200px;"Required/>
				</td>
				<td>
				 	Gender:
				 	<br/>
				 	<select  name="ddGender" style="width:200px;" Required>
						<option value="">Select</option>
					  	<option value="Male">Male</option>
					  	<option value="Female">Female</option>
					  	<option value="Other">Other</option>
					</select> 
				</td>
			</tr>
			<tr>
				<td colspan="2">
					Permanant Address:
					<br/>
					<textarea name='txtAddress' style="width:450px;" Required></textarea>
				</td>
			</tr>
			<tr> 
				 <td>
				 	Department:
				 	<br/>
				 	<select  name="ddDept" style="width:200px;" Required>
						<option value="">Select</option>
					  	<option value="CS">CS</option>
					  	<option value="MCA">MCA</option>
					  	<option value="MBA">MBA</option>
					</select> 
				</td>
				<td>Contact No:<br/><input type="text" style="width:200px;" name="txtContactNo" Required pattern='[0-9]{10}'/></td>
				<td>Parent Contact No:<br/><input type="text" style="width:200px;" name="txtParentContactNo" Required pattern='[0-9]{10}'/></td>
			</tr>
			<tr>
			
				<td>Date of Birth:<br/><input type="Date" style="width:100px;" name="txtDOB" Required/></td>
				<td>Email ID:<br/><input type="email" style="width:200px;" name="txtEMailId" Required/></td>
				<td>Aadhaar Number:<br/><input type="aadhaarno" style="width:200px;" name="txtAadhaarNo" Required/></td>
				 
			</tr>
			<tr>
				<td>Year of Joining:<br/><input type="text" name="txtYearOfJoin" style="width:200px;" Required/></td>
				<td>
					Scholorship:<BR/><input type="text" name="txtScholarship" style="width:200px;" Required/></td></tr>
					<br/>
					
				
				<td>
				 	First Graduate:
				 	<br/>
				 	<select  name="ddFirstGraduate" style="width:200px;" Required>
						<option value="">Select</option>
					  	<option value="yes">Yes</option>
					  	<option value="no">No</option>
					
					</select> 
				</td>
			</tr>
			<tr>
				<td>SSLC Roll Number:<br/><input type="text" name="textSSLCRollNo" style="width:200px;" Required/></td>
				<td>SSLC Mark:<br/><input type="text" name="textSSLCMark" style="width:200px;" Required/></td>
				<td>SSLC Percentage:<br/><input type="text" name="txtSSLCPercentage" style="width:200px;" Required/></td>
			</tr>
			<tr>
				<td>HSC Roll Number:<br/><input type="text" name="textHSCRollNo" style="width:200px;" Required/></td>
				<td>HSC Mark:<br/><input type="text" name="textHSCMark" style="width:200px;" Required/></td>
				<td>HSC Percentage:<br/><input type="text" name="txtSSLCPercentage" style="width:200px;" Required/></td>
			</tr>
			<tr>
				<td>
				 	Of from Government School:
				 	<br/>
				 	<select  name="ddGovernment" style="width:200px;" Required>
						<option value="">Select</option>
					  	<option value="yes">Yes</option>
					  	<option value="no">No</option>
					
					</select> 
				</td>
				<td>
				 	Hosteller:
				 	<br/>
				 	<select  name="ddHosteller" style="width:200px;" Required>
						<option value="">Select</option>
					  	<option value="yes">Yes</option>
					  	<option value="no">No</option>
					
					</select> 
				</td>
			</tr>
			<tr>
			
			
				<td>Password:</td>
				
				<td><input type="password" style="width:200px;" name="txtPass" Required/></td>
				
				 
			</tr>
			<tr>
				<td colspan="2">
					<br/>
					<input type="submit" name="btnSubmit" value="Submit" class="btn_submit" style="width:500px;" />
				</td>
			</tr>
		</table>
	</form>

	</div>

	<br/>
	<br/>
	<br/>


</div>
</body>
</html>