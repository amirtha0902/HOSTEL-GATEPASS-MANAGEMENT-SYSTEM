-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2022 at 01:40 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `alumni`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintable`
--

CREATE TABLE IF NOT EXISTS `admintable` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admintable`
--

INSERT INTO `admintable` (`Username`, `Password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `chattable`
--

CREATE TABLE IF NOT EXISTS `chattable` (
  `Sno` int(11) NOT NULL,
  `FromID` varchar(10) NOT NULL,
  `ToID` varchar(10) NOT NULL,
  `Message` varchar(500) NOT NULL,
  `OnDate` datetime NOT NULL,
  PRIMARY KEY (`Sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chattable`
--

INSERT INTO `chattable` (`Sno`, `FromID`, `ToID`, `Message`, `OnDate`) VALUES
(1, 'S001', 'S001', 'hai', '2020-03-16 06:47:46');

-- --------------------------------------------------------

--
-- Table structure for table `eventtable`
--

CREATE TABLE IF NOT EXISTS `eventtable` (
  `EventID` int(11) NOT NULL,
  `EventName` varchar(50) NOT NULL,
  `OnDate` date NOT NULL,
  `Description` varchar(200) NOT NULL,
  PRIMARY KEY (`EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `infotable`
--

CREATE TABLE IF NOT EXISTS `infotable` (
  `Sno` int(11) NOT NULL,
  `OnDate` date NOT NULL,
  `RegNo` varchar(10) NOT NULL,
  `Information` varchar(500) NOT NULL,
  PRIMARY KEY (`Sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infotable`
--

INSERT INTO `infotable` (`Sno`, `OnDate`, `RegNo`, `Information`) VALUES
(1, '2020-03-16', 'S001', 'International Conference at wipro, tidal park, Chennai'),
(2, '2022-11-04', 'admin', 'tomorrow will be a holiday'),
(3, '2022-11-07', 'admin', 'coming friday is a holiday');

-- --------------------------------------------------------

--
-- Table structure for table `stafftable`
--

CREATE TABLE IF NOT EXISTS `stafftable` (
  `StaffID` varchar(10) NOT NULL,
  `StaffName` varchar(20) NOT NULL,
  `Dept` varchar(50) NOT NULL,
  `ContactNo` varchar(10) NOT NULL,
  `EmailID` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  PRIMARY KEY (`StaffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stafftable`
--

INSERT INTO `stafftable` (`StaffID`, `StaffName`, `Dept`, `ContactNo`, `EmailID`, `Password`) VALUES
('S001', 'Ram', 'CS', '9985625144', 'ram43@gmail.com', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `RegNo` varchar(10) NOT NULL,
  `StudentName` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Branch` varchar(20) NOT NULL,
  `ContactNo` varchar(20) NOT NULL,
  `ParentContactNo` varchar(20) NOT NULL,
  `DOB` datetime NOT NULL,
  `EmailID` varchar(50) NOT NULL,
  `AadhaarNo` varchar(20) NOT NULL,
  `Caste` varchar(20) NOT NULL,
  `Region` varchar(50) NOT NULL,
  `Nationality` varchar(200) NOT NULL,
  `YearOfJoin` varchar(10) NOT NULL,
  `Scholarship` varchar(20) NOT NULL,
  `FirstGraduate` varchar(20) NOT NULL,
  `SSLCRollNo` varchar(20) NOT NULL,
  `SSLCMark` varchar(20) NOT NULL,
  `SSLCPercentage` varchar(20) NOT NULL,
  `HSCRollNo` varchar(20) NOT NULL,
  `HSCMark` varchar(20) NOT NULL,
  `HSCPercentage` varchar(20) NOT NULL,
  `School` varchar(20) NOT NULL,
  `Hosteller` varchar(20) NOT NULL,
  PRIMARY KEY (`RegNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`RegNo`, `StudentName`, `Gender`, `Address`, `Branch`, `ContactNo`, `ParentContactNo`, `DOB`, `EmailID`, `AadhaarNo`, `Caste`, `Region`, `Nationality`, `YearOfJoin`, `Scholarship`, `FirstGraduate`, `SSLCRollNo`, `SSLCMark`, `SSLCPercentage`, `HSCRollNo`, `HSCMark`, `HSCPercentage`, `School`, `Hosteller`) VALUES
('S001', 'Bala', 'Male', '34,PS Park\r\nErode', 'CS', '9089786756', '9123456780', '1997-10-07 00:00:00', 'bala@gmail.com', '890134769823', 'Thevar', 'Hindu', 'Indian', '2016', 'nil', 'yes', '678123', '460', '78', '345987', '1045', '78', 'Yes', 'no'),
('S002', 'Aruna', 'Female', '12,Anna nagar', 'CS', '9089786778', '9123405678', '1997-09-11 00:00:00', 'aruna@gmail.com', '912345679876', 'Thevar', 'Hindu', 'Indian', '2016', 'nil', 'yes', '123456', '456', '85', '234654', '1066', '85', 'yes', 'yes');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
