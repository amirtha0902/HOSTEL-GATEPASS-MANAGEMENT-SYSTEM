<?php
	include('Db.php');

   /* $SNo = "";
    foreach($_POST as $name => $content){
    $SNo= $name;
    }*/
	//$Id = array_keys($_POST)[0];
	$SNo =$_REQUEST['sno'];
	if($_REQUEST['type']=="approve")
	{
	$qry="Update GatePass Set Status='Approved' Where SNo = '". $SNo ."' ";
	$msg="Gate Pass Request Accepted.";
	}
	else
	{
		$qry="Update GatePass Set Status='Rejected' Where SNo = '". $SNo ."' ";
		$msg="Gate Pass Request Rejected.";
	}
	
	
		
					
	mysqli_query($con,$qry) or die(mysqli_error());
	
	
	
		if($msg!="")
					{
						$query = mysqli_query($con,"Select EMailID From student Where RegNo in (Select RegNo From Gatepass Where SNo="  . $SNo . ")");
						$EMailID='';
			if($r = mysqli_fetch_assoc($query))
			{
				$EMailID=$r['EMailID'];
				//echo $EMailID;
				//return;
						 	//----mail logic
		     require 'PHPMailer/PHPMailerAutoload.php';

      $mail = new PHPMailer;

      //$mail->SMTPDebug = 3;                               // Enable verbose debug output

      $mail->isSMTP();                                      // Set mailer to use SMTP

      $mail->SMTPOptions = array(
      'ssl' => array(
          'verify_peer' => false,
          'verify_peer_name' => false,
          'allow_self_signed' => true));
  
  
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->Mailer = "smtp";
		
		$mail->SMTPDebug  = 0;  
		$mail->SMTPAuth   = TRUE;
		$mail->SMTPSecure = "tls";
		$mail->Port       = 587;
		$mail->Host       = "smtp.gmail.com";
		$mail->Username   = "softproms14@gmail.com";
		$mail->Password   = "desjuujiftycrvfv";
		$mail->IsHTML(true);
		$mail->AddAddress($EMailID,"Student");// "softproms14@gmail.com", "Administrator"); //toaddress , recipient name
		$mail->SetFrom("softproms14@gmail.com", "Admin");
		//$mail->AddReplyTo("reply-to-email@domain", "reply-to-name");
		//$mail->AddCC("cc-recipient-email@domain", "cc-recipient-name");
		$mail->Subject = "Gate Pass Status";
		//$content = "<b> Your House Construction Request Accepted. Our Admin will Contact you shortly.</b>";
		$mail->MsgHTML($msg); 
		if(!$mail->Send()) {
			echo "Error while sending Email.";
			//var_dump($mail);
		}
		else {
				echo "Email sent successfully";
		}

			}
		
		//--mail logic
						
						
						
						
					}
					
		header('location:ViewRequests.php');
?>