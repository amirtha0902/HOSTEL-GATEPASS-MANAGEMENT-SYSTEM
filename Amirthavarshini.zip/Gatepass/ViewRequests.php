<?php
session_start();
if (isset($_SESSION['usertype']))
{
	if($_SESSION['usertype']=="admin")
	{
	include('HeaderAdmin.php');
	}
	else if($_SESSION['usertype']=="staff")
	{
	include('HeaderStaff.php');
	}
	else if($_SESSION['usertype']=="student")
	{
	include('HeaderStudent.php');
	}
}
else
{
	header('location:index.php');
}

include('Db.php');
?>

	<form action="" method="POST">

	<table class="mygrid" align="center">

		<tr><td colspan="9">GATE PASS REQUEST DETAILS<br><br><td><tr>

		<?php
			if($_SESSION['usertype']=="admin")
			{
				?>
		<tr>
			<td colspan="9">

			<select  name="ddDept">
				<option value="">All Dept</option>
			  	<option value="CS">CS</option>
			  	<option value="MCA">MCA</option>
			  	<option value="MBA">MBA</option>
			</select> 

			<input type="submit" name="btnSubmit" value="Search" class="btn_submit" />

			<br><br>

			<td>
		<tr>
		<?php
			}
			?>
		
		
		<tr><th>S.No. </th><th>Register No.</th><th>Student Name.</th><th>Staff ID</th><th>Staff Name</th><th>Department</th><th>Entry Date</th><th>On Date</th><th>Reason</th>
		<th>Duration</th>
		<th>Status</th>
		</tr>

		<?php

	
			//$year = $_REQUEST['ddYear'];
			if($_SESSION['usertype']=="admin")
			{
					if ($_SERVER["REQUEST_METHOD"] == "POST") 
			{
			$dept = $_REQUEST['ddDept'];

			
			$query = mysqli_query($con,"Select a.*,b.StaffName,c.StudentName From GatePass a,Stafftable b,Student c Where a.StaffID=b.StaffID and a.RegNo=c.RegNo and a.Dept LIKE '". '%' . $dept . '%' ."' ");
			
			While($r = mysqli_fetch_assoc($query))
			{
				if($r['Status']=='Approved')
				{
					echo "<tr><td>" . $r['SNo'] . "</td><td>" . $r['RegNo'] . "</td><td>" . $r['StudentName'] . "</td><td>" . $r['StaffID'] . "</td><td>" . $r['StaffName'] . "</td><td>" . $r['Dept'] . "</td><td>" . $r['EntryDate'] . "</td><td>" . $r['OnDate'] . "</td><td>" . $r['Reason'] . "</td><td>" . $r['Duration'] . "</td><td style='color:green'>" . $r['Status'] . "</td></tr>";
				}
				else
				{
				echo "<tr><td>" . $r['SNo'] . "</td><td>" . $r['RegNo'] . "</td><td>" . $r['StudentName'] . "</td><td>" . $r['StaffID'] . "</td><td>" . $r['StaffName'] . "</td><td>" . $r['Dept'] . "</td><td>" . $r['EntryDate'] . "</td><td>" . $r['OnDate'] . "</td><td>" . $r['Reason'] . "</td><td>" . $r['Duration'] . "</td><td style='color:red'>" . $r['Status'] . "</td></tr>";
				}
			}
			}
			}
			else if($_SESSION['usertype']=="staff")
			{
				$dept = $_SESSION['Dept'];
		
			$query = mysqli_query($con,"Select a.*,b.StaffName,c.StudentName From GatePass a,Stafftable b,Student c Where a.StaffID=b.StaffID and a.RegNo=c.RegNo and a.Dept LIKE '". '%' . $dept . '%' ."' ");
			While($r = mysqli_fetch_assoc($query))
			{
				if($r['Status']=='Pending' || $r['Status']=='Rejected')
				{
				echo "<tr><td>" . $r['SNo'] . "</td><td>" . $r['RegNo'] . "</td><td>" . $r['StudentName'] . "</td><td>" . $r['StaffID'] . "</td><td>" . $r['StaffName'] . "</td><td>" . $r['Dept'] . "</td><td>" . $r['EntryDate'] . "</td><td>" . $r['OnDate'] . "</td><td>" . $r['Reason'] . "</td><td>" . $r['Duration'] . "</td><td style='color:red'>" . $r['Status'] . "&nbsp;<a href='ViewRequestsCode.php?type=approve&sno=" . $r['SNo'] . "' value='Approve' class='btn_submit '>Approve</a>&nbsp;<a href='ViewRequestsCode.php?type=reject&sno=" . $r['SNo'] . "' value='Reject' class='btn_delete'>Reject</a></td></tr>";
				}
				else
				{
					echo "<tr><td>" . $r['SNo'] . "</td><td>" . $r['RegNo'] . "</td><td>" . $r['StudentName'] . "</td><td>" . $r['StaffID'] . "</td><td>" . $r['StaffName'] . "</td><td>" . $r['Dept'] . "</td><td>" . $r['EntryDate'] . "</td><td>" . $r['OnDate'] . "</td><td>" . $r['Reason'] . "</td><td>" . $r['Duration'] . "</td><td style='color:green'>" . $r['Status'] . "</td></tr>";
				}
			}
			}
		else if( $_SESSION['usertype']=="student")
			{
				$dept = $_SESSION['Dept'];
		
			$query = mysqli_query($con,"Select a.*,b.StaffName,c.StudentName From GatePass a,Stafftable b,Student c Where a.StaffID=b.StaffID and a.RegNo=c.RegNo and a.Dept LIKE '". '%' . $dept . '%' ."' ");
			While($r = mysqli_fetch_assoc($query))
			{
				if($r['Status']=='Pending' || $r['Status']=='Rejected')
				{
				echo "<tr><td>" . $r['SNo'] . "</td><td>" . $r['RegNo'] . "</td><td>" . $r['StudentName'] . "</td><td>" . $r['StaffID'] . "</td><td>" . $r['StaffName'] . "</td><td>" . $r['Dept'] . "</td><td>" . $r['EntryDate'] . "</td><td>" . $r['OnDate'] . "</td><td>" . $r['Reason'] . "</td><td>" . $r['Duration'] . "</td><td style='color:red'>" . $r['Status'] . "</td></tr>";
				}
				else
				{
						echo "<tr><td>" . $r['SNo'] . "</td><td>" . $r['RegNo'] . "</td><td>" . $r['StudentName'] . "</td><td>" . $r['StaffID'] . "</td><td>" . $r['StaffName'] . "</td><td>" . $r['Dept'] . "</td><td>" . $r['EntryDate'] . "</td><td>" . $r['OnDate'] . "</td><td>" . $r['Reason'] . "</td><td>" . $r['Duration'] . "</td><td style='color:green'>" . $r['Status'] . "</td></tr>";
				}
			}
			}
		?>
		
		
	
	</table>

	</form>
	
</body>
</html>