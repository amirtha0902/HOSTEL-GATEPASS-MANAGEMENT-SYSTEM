
<?php
include('HeaderAdmin.php');
include('Db.php');
?>

	<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">

	<table class="mygrid" align="center">

		<tr><td colspan="9">GATE PASS REQUEST DETAILS<br><br><td><tr>

		<tr>
			<td colspan="9">

			
			<select  name="ddDept">
				<option value="">All Dept</option>
			  	<option value="CS">CS</option>
			  	<option value="MCA">MCA</option>
			  	<option value="MBA">MBA</option>
			</select> 

			<input type="submit" name="btnSubmit" value="Search" class="btn_submit" />

			<br><br>

			<td>
		<tr>
		
		<tr><th>StaffID</th><th>StaffName</th><th>Department</th><th>ContactNo</th><th>MailId</th></tr>

		<?php

		if ($_SERVER["REQUEST_METHOD"] == "POST") 
		{
			//$year = $_REQUEST['ddYear'];
			$dept = $_REQUEST['ddDept'];

			$query = mysqli_query($con,"Select * From stafftable Where Dept LIKE '". '%' . $dept . '%' ."' ");
			While($r = mysqli_fetch_assoc($query))
			{
				echo "<tr><td>" . $r['StaffID'] . "</td><td>" . $r['StaffName'] . "</td><td>" . $r['Dept'] . "</td><td>" . $r['ContactNo'] . "</td><td>" . $r['EmailID'] . "</td></tr>";
			}
			
		}
		?>
		
		
	
	</table>

	</form>
	
</body>
</html>