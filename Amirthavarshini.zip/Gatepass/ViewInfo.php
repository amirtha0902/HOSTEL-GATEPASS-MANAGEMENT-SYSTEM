
<?php
include('HeaderAdmin.php');
include('Db.php');
?>

<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
		
	<table class="mygrid" align="center">

		<tr>
			<td colspan="9">ADMIN POSTED INFORMATIONS
			<br>
			<br>
			<input type='date' name='txtFromDate' Required pattern="([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))" value="<?php if(isset($_REQUEST['txtFromDate'])) { echo $_REQUEST['txtFromDate']; } ?>" />

			<input type='date' name='txtToDate' Required pattern="([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))" value="<?php if(isset($_REQUEST['txtToDate'])) { echo $_REQUEST['txtToDate']; } ?>" />
			
			<input type="submit" value="SHOW" class="btn_submit"/>
			<br>
			<br>
			</td>
		<tr>

		<tr><th>Sno</th><th>RegNo</th><th>OnDate</th><th>Information</th></tr>
		<?php
			if(isset($_REQUEST['txtFromDate']))
			{
			$query = mysqli_query($con,"Select * From InfoTable Where OnDate >= '". $_REQUEST['txtFromDate'] ."' and OnDate <= '". $_REQUEST['txtToDate'] ."'  ");
			While($r = mysqli_fetch_assoc($query))
			{
				echo "<tr><td>" . $r['Sno'] . "</td><td>" . $r['RegNo'] . "</td><td>" . $r['OnDate'] . "</td><td>" . $r['Information'] . "</td></tr>";
			}
			mysqli_close($con);
		}
		?>
	
	</table>
	
</form>

</body>
</html>