-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 04, 2023 at 07:19 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gatepass`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintable`
--

CREATE TABLE IF NOT EXISTS `admintable` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admintable`
--

INSERT INTO `admintable` (`Username`, `Password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `gatepass`
--

CREATE TABLE IF NOT EXISTS `gatepass` (
  `SNo` int(11) NOT NULL,
  `StaffID` varchar(20) NOT NULL,
  `RegNo` varchar(20) NOT NULL,
  `Dept` varchar(20) NOT NULL,
  `EntryDate` date NOT NULL,
  `OnDate` date NOT NULL,
  `Reason` varchar(200) NOT NULL,
  `Duration` varchar(200) NOT NULL,
  `Status` varchar(10) NOT NULL,
  PRIMARY KEY (`SNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gatepass`
--

INSERT INTO `gatepass` (`SNo`, `StaffID`, `RegNo`, `Dept`, `EntryDate`, `OnDate`, `Reason`, `Duration`, `Status`) VALUES
(1, 'ST001', 'stu001', 'MCA', '2022-11-14', '2022-11-14', 'OD', '1 day', 'Approved'),
(2, 'ST102', 'stu002', 'CS', '2022-11-14', '2022-11-14', 'IPT', '2 days', 'Pending'),
(3, 'ST001', 'STU001', 'MCA', '2022-11-14', '2022-11-15', 'Family function', '2 hours', 'Approved'),
(4, 'ST001', 'STU001', 'MCA', '2022-11-14', '2022-11-16', 'Inter college meet', '1 day', 'Approved'),
(5, 'ST102', 'stu003', 'CS', '2022-11-14', '2022-11-16', 'Inter college meet', '1 day', 'Pending'),
(6, 'ST102', 'stu003', 'CS', '2022-11-14', '2022-11-18', 'OD', '3 Hours', 'Pending'),
(7, 'ST002', 'STU004', 'CS', '2022-11-14', '2022-11-14', 'OD', '2days', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `stafftable`
--

CREATE TABLE IF NOT EXISTS `stafftable` (
  `StaffID` varchar(10) NOT NULL,
  `StaffName` varchar(20) NOT NULL,
  `Dept` varchar(50) NOT NULL,
  `ContactNo` varchar(10) NOT NULL,
  `EmailID` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `StaffType` varchar(10) NOT NULL,
  PRIMARY KEY (`StaffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stafftable`
--

INSERT INTO `stafftable` (`StaffID`, `StaffName`, `Dept`, `ContactNo`, `EmailID`, `Password`, `StaffType`) VALUES
('ST001', 'arun', 'MCA', '9089786756', 'arunerd@gmail.com', '123', 'HOD'),
('ST002', 'Akila', 'CS', '9876543432', 'akila@gmail.com', '123', 'HOD'),
('ST102', 'Priya', 'CS', '9089786756', 'priyacs@gmail.com', '123', 'HOD');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `RegNo` varchar(10) NOT NULL,
  `StudentName` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Dept` varchar(20) NOT NULL,
  `ContactNo` varchar(20) NOT NULL,
  `ParentContactNo` varchar(20) NOT NULL,
  `DOB` datetime NOT NULL,
  `EmailID` varchar(50) NOT NULL,
  `AadhaarNo` varchar(20) NOT NULL,
  `YearOfJoin` varchar(10) NOT NULL,
  `Scholarship` varchar(20) NOT NULL,
  `FirstGraduate` varchar(20) NOT NULL,
  `SSLCRollNo` varchar(20) NOT NULL,
  `SSLCMark` varchar(20) NOT NULL,
  `SSLCPercentage` varchar(20) NOT NULL,
  `HSCRollNo` varchar(20) NOT NULL,
  `HSCMark` varchar(20) NOT NULL,
  `HSCPercentage` varchar(20) NOT NULL,
  `School` varchar(20) NOT NULL,
  `Hosteller` varchar(20) NOT NULL,
  `Password` varchar(15) NOT NULL,
  PRIMARY KEY (`RegNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`RegNo`, `StudentName`, `Gender`, `Address`, `Dept`, `ContactNo`, `ParentContactNo`, `DOB`, `EmailID`, `AadhaarNo`, `YearOfJoin`, `Scholarship`, `FirstGraduate`, `SSLCRollNo`, `SSLCMark`, `SSLCPercentage`, `HSCRollNo`, `HSCMark`, `HSCPercentage`, `School`, `Hosteller`, `Password`) VALUES
('STU001', 'kumar', 'Male', '12,anna nagar\r\nErode', 'MCA', '9089786778', '9123405678', '2002-10-18 00:00:00', 'kumar@gmai.clom', '123456781234', '2021', 'nil', 'no', '345123', '460', '85', '345987', '1045', '85', 'yes', 'yes', 'aaa'),
('STU002', 'Aruna', 'Female', '12,Anna nagar', 'MCA', '9089786778', '9123405678', '1997-09-11 00:00:00', 'aruna@gmail.com', '912345679876', '2016', 'nil', 'yes', '123456', '456', '85', '234654', '1066', '85', 'yes', 'yes', 'aaa'),
('STU003', 'Bala', 'Male', '34,PS Park\r\nErode', 'CS', '9089786756', '9123456780', '1997-10-07 00:00:00', 'bala@gmail.com', '890134769823', '2016', 'nil', 'yes', '678123', '460', '78', '345987', '1045', '78', 'Yes', 'no', 'aaa'),
('STU004', 'Jeni', 'Female', '11,periyar nagar,\r\nerode.', 'CS', '9089786778', '9123405678', '2000-01-07 00:00:00', 'jeni@gmail.com', '123456781234', '2019', 'Nil', 'yes', '123456', '470', '75', '234654', '1010', '75', 'yes', 'no', 'aaa');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
