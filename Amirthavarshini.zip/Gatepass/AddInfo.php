
<?php
include('HeaderAdmin.php');
?>
	
	<br/>

	<div style="margin-left: 10%; text-align: left;">

	<h4>YOUR INFORMATION HERE</h4>

	<form action="AddInfoCode.php" method="post" >
		<table style="text-align:left;">
			<tr>
				<td>
					<textarea name='txtInfo' style="width:500px; height: 200px;" Required></textarea>
				</td>
			</tr>
			<tr>
				<td>
					<br/><input type="submit" name="btnSubmit" value="POST" class="btn_submit" style="width:500px;" /></td>
			</tr>
		</table>
	</form>

	</div>

</div>
</body>
</html>