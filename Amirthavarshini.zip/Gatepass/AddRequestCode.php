<?php
//error_reporting(0);
session_start();
include('HeaderStudent.php');
?>

<?php
	include('Db.php');
	
	$StaffID=$_POST["ddStaff"];
	$ondate=$_POST["txtDate"];
	$reason=$_POST["txtReason"];
	$hours=$_POST["txtHours"];
	
	
$sql="Select Count(*) as Records From GatePass";
							$res=mysqli_query($con,$sql) or die(mysqli_error());
								$row = mysqli_fetch_assoc($res);
							
		
				$SNo=($row['Records']+1);
				
	$qry="Insert Into GatePass Values('". $SNo ."','". $StaffID . "','" . $_SESSION['registerno'] . "','" . $_SESSION['Dept'] ."','". date('Y-m-d') ."','"  . $ondate ."','". $reason ."','". $hours ."','Pending')";
	mysqli_query($con,$qry) or die(mysqli_error());
   	echo "<br/><br/>Gate Pass Request Saved Successfully!<br/>";
	mysqli_close($con);
?>