<?php
//error_reporting(0);
session_start();
include('HeaderStudent.php');
include('Db.php');
?>
	
	<h4>GATEPASS REQUEST<h4>

	<form action="AddRequestCode.php" method="post" enctype="multipart/form-data">
		<table style="text-align:left;" align="center">
			<tr>
				<td align="right">To:</td> 
				<td>
				<select name="ddStaff" Required>
				<?php
				$query = mysqli_query($con, "Select StaffID, staffname From stafftable Where Dept='"  . $_SESSION['Dept'] . "'");
				//echo $query;
				//return;
				echo "<option value=''>Select</option>";
				while($r = mysqli_fetch_assoc($query))
				{
					echo "<option value='". $r['StaffID'] . "' >" . $r['StaffID'] . ":" . $r['staffname'] ."</option>";
				}
				?>
				</select>
				</td>
			</tr>
			<tr>
				<td align="right">On Date:</td> <td><input type="text" name="txtDate" value="<?php echo date('Y-m-d'); ?>" Required/></td>
			</tr>
			<tr>
				<td align="right">Reason:</td> 
				<td>
					<textarea name='txtReason' row="5" cols="30"></textarea>
				</td>
			</tr>
			<tr>
				<td align="right">Hours/Day:</td> <td><input type="text" name="txtHours" Required/></td>
			</tr>
			
			<tr>
				<td></td> <td><input type="submit" name="btnSubmit" value="Submit" class="btn_submit" style="width:152px;" /></td>
			</tr>
		</table>
	</form>


</div>
</body>
</html>