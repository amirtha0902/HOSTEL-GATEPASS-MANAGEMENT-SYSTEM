
<?php
include('Header.php');
?>
	
	<p align="center" style="width:100%">
<div style="width:90%;height:600; background-image: url('home.jpg'); background-size: cover;">
</p>
	<br/>

	<p> </p>

</div>

</body>
</html>