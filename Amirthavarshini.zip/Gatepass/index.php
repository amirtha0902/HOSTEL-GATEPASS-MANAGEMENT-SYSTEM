<html>
<head>
<link rel="stylesheet" type="text/css" href="Style.css"></link>
</head>

<body id="bdy-main">
	
	<?php
    header('location:Home.php');
	?>
	
</body>
</html>