 <?php
    $con = mysqli_connect("localhost","root","","gatepass");
	mysqli_select_db($con,"gatepass");
	if (!$con)
	{
		die('Could not connect: ' . mysqli_error());
	}
?>