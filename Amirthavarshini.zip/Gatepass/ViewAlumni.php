
<?php
include('HeaderAdmin.php');
include('Db.php');
?>

	<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">

	<table class="mygrid" align="center">

		<tr><td colspan="9">STUDENT DETAILS<br><br><td><tr>

		<tr>
			<td colspan="9">

			
			<select  name="ddDept">
				<option value="">All Dept</option>
			  	<option value="CS">CS</option>
			  	<option value="MCA">MCA</option>
			  	<option value="MBA">MBA</option>
			</select> 

			<input type="submit" name="btnSubmit" value="Search" class="btn_submit" />

			<br><br>

			<td>
		<tr>
		
		<tr><th>RegNo</th><th>Name</th><th>Address</th><th>Dept</th><th>ContactNo</th><th>MailId</th><th>Year Of Join</th><th>Government School</th><th>Hostel</th></tr>

		<?php

		if ($_SERVER["REQUEST_METHOD"] == "POST") 
		{
			//$year = $_REQUEST['ddYear'];
			$dept = $_REQUEST['ddDept'];

			$query = mysqli_query($con,"Select * From Student Where Dept LIKE '". '%' . $dept . '%' ."' ");
			While($r = mysqli_fetch_assoc($query))
			{
				echo "<tr><td>" . $r['RegNo'] . "</td><td>" . $r['StudentName'] . "</td><td>" . $r['Address'] . "</td><td>" . $r['Branch'] . "</td><td>" . $r['ContactNo'] . "</td><td>" . $r['EmailID'] . "</td><td>" . $r['YearOfJoin'] . "</td><td>" . $r['School'] . "</td><td>" . $r['Hosteller'] . "</td></tr>";
			}
			
		}
		?>
		<table class="mygrid" align="center">

		<tr><td colspan="9">NUMBER OF STUDENTS<br><br><td></tr>
		<tr><th>CATEGORY</th><th>NUMBER OF STUDENTS</th>
		<?php
		if ($_SERVER["REQUEST_METHOD"] == "POST") 
		{
			//$year = $_REQUEST['ddYear'];
			$dept = $_REQUEST['ddDept'];

		$qry = mysqli_query($con,"Select School,COUNT(*) AS data From Student Where School='Yes'group by(School)");
		While($rs = mysqli_fetch_assoc($qry))
			{
				echo"<tr><td>Government school</td><td>".$rs['data']."</td></tr>";
			}
			
		
		$qry = mysqli_query($con,"Select Hosteller,COUNT(*) AS data From Student Where Hosteller='Yes'group by(Hosteller)");
		While($rs = mysqli_fetch_assoc($qry))
			{
				echo"<tr><td>Hosteller</td><td>".$rs['data']."</td></tr>";
			}
			mysqli_close($con);
		}
		?>
	
	</table>

	</form>
	
</body>
</html>