<?php
session_start();
if (isset($_SESSION['usertype']))
{
	if($_SESSION['usertype']=="admin")
	{
	include('HeaderAdmin.php');
	}
else if($_SESSION['usertype']=="staff")
	{
	include('HeaderStaff.php');
	}
else if($_SESSION['usertype']=="student")
	{
	include('HeaderStudent.php');
}
}
else
{
	location('header:index.php');
}

include('Db.php');
?>

	<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">

	<table class="mygrid" align="center">

		<tr><td colspan="9">STAFF DETAILS<br><br><td><tr>

		<tr>
			<td colspan="9">

			
			<select  name="ddDept">
				<option value="">All Dept</option>
			  	<option value="CS">CS</option>
			  	<option value="MCA">MCA</option>
			  	<option value="MBA">MBA</option>
			</select> 

			<input type="submit" name="btnSubmit" value="Search" class="btn_submit" />

			<br><br>

			<td>
		<tr>
		
		<tr><th>Staff ID</th><th>Staff Name</th><th>Department</th><th>Staff Type</th><th>Contact No.</th><th>Mail Id</th></tr>

		<?php

		if ($_SERVER["REQUEST_METHOD"] == "POST") 
		{
			//$year = $_REQUEST['ddYear'];
			$dept = $_REQUEST['ddDept'];

			$query = mysqli_query($con,"Select * From stafftable Where Dept LIKE '". '%' . $dept . '%' ."' ");
			While($r = mysqli_fetch_assoc($query))
			{
				echo "<tr><td>" . $r['StaffID'] . "</td><td>" . $r['StaffName'] . "</td><td>" . $r['Dept'] . "</td><td>" . $r['StaffType'] . "</td><td>" . $r['ContactNo'] . "</td><td>" . $r['EmailID'] . "</td></tr>";
			}
			
		}
		?>
		
		
	
	</table>

	</form>
	
</body>
</html>