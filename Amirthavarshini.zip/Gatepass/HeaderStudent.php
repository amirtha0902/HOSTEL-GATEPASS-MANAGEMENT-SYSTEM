<html>

<head>
	<link href="Content/Style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="navbar" id="Mymenu-">
  
  <a href="ViewRequests.php" style="float: right;">View Gate Pass Request</a>
  <a href="AddRequest.php" style="float: right;">Add Gate Pass Request</a>
  <a href="ViewStaffs.php" style="float: right;">Staff List</a>
   
  <a href="Signout.php" style="float: right;">Logout</a>
</div>


