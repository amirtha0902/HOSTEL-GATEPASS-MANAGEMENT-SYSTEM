<html>

<head>
	<link href="Content/Style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="navbar" id="Mymenu">
  <a href="Home.php">HOME</a>
  <!--<a href="ContactUs.php">CONTACT US</a>-->
  
  <a href="Login.php" style="float:right;">ADMIN LOGIN</a>
  <a href="LoginStaff.php" style="float:right;">STAFF LOGIN</a>
  <a href="LoginStudent.php" style="float:right;">STUDENT LOGIN</a>
  
</div>
