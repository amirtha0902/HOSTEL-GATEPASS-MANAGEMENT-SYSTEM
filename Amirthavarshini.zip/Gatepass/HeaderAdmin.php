<html>

<head>
	<link href="Content/Style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="navbar" id="Mymenu-">
  
  <a href="RegStaff.php" style="float: right;">Add Staff</a>
  <a href="RegStudent.php" style="float: right;">Add Student</a>
  <a href="ViewStaffs.php" style="float: right;">Staff List</a>
  <a href="ViewStudents.php" style="float: right;">Student List</a>
    <a href="ViewRequests.php" style="float: right;">View Gate Pass Request</a>
  
  
   
  <a href="signout.php" style="float: right;">Logout</a>
</div>


