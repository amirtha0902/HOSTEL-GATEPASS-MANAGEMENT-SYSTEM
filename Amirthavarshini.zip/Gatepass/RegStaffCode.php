<?php
include('HeaderAdmin.php');
?>

<?php
	include('Db.php');
	
	$RegNo=$_POST["txtId"];
	$Name=$_POST["txtName"];
	$Branch=$_POST["ddDept"];
	$ContactNo=$_POST["txtContactNo"];
	$MailId=$_POST["txtEMailId"];
	$pass=$_POST["txtPass"];
		$stype=$_POST["ddType"];
		
	$qry="Insert Into stafftable Values('". $RegNo ."','". $Name ."','". $Branch ."','". $ContactNo ."','". $MailId ."','". $pass ."','" . $stype . "')";
	mysqli_query($con,$qry) or die(mysqli_error());
   	echo "<br/><br/>Staff Registraion Successfully!<br/>";
	mysqli_close($con);
?>