
<?php
include('Header.php');
?>
	
	<br/>
	<center><h4>STAFF LOGIN</h4></center>

	<form action="LoginStaffCode.php" method="post">
		<table class="tbl" align="center" class="login-style">
			<tr>
				<td colspan="2" align='center'>
					<img src="Image/login1.jpg" style="max-width:180px;" />
				</td>
			</tr>
			<tr>
			<td>Staff ID.
			</td>
			
				<td><input type="text" name="txtSID" placeholder=" Staff Id." Style="width:180px; text-align:center;" Required /></td>
			</tr>
			<tr>
			<td>Password
			</td>
				<td><input type="password" name="txtPassword" placeholder="Password" Style="width:180px; text-align:center;" Required/></td>
			</tr>
			<tr>
				<td colspan="2" align='center'><br><input type="submit" name="btnSubmit" value="Login" class="btn_submit" Style="width:180px;"/></td>
			</tr>
		</table>
	</form>


</div>
</body>
</html>