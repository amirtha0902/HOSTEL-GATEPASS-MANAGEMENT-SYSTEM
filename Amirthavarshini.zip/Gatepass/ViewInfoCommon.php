
<?php
include('Header.php');
include('Db.php');
?>

<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
		
	<table class="mygrid" align="center">

		<tr>
			<td colspan="9">ALUMNI POSTED INFORMATIONS<br><br></td>
		<tr>

		<tr><th>OnDate</th><th>Information</th></tr>
		<?php
			$query = mysqli_query($con,"Select * From InfoTable Where OnDate >= '". date('Y-m-d') ."'  ");
			While($r = mysqli_fetch_assoc($query))
			{
				echo "<tr><td>" . $r['OnDate'] . "</td><td>" . $r['Information'] . "</td></tr>";
			}
			mysqli_close($con);
		?>
	</table>
	
</form>

</body>
</html>