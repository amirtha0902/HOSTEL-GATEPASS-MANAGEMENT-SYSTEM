<?php
    session_start();
    include('Db.php');
	
	$Username = $_POST["txtRegNo"];
	$Password = $_POST["txtPassword"];
	
		$query= mysqli_query($con,"Select Count(*) as data From Student Where RegNo = '". $Username ."' and Password = '". $Password ."' ");
		$row = mysqli_fetch_assoc($query);
		if($row['data']==1){
			$_SESSION["username"] = $Username;
			$_SESSION["registerno"] = $Username;
			$_SESSION["usertype"]="student";
			$query= mysqli_query($con,"Select Dept From Student Where RegNo = '". $Username ."' and Password = '". $Password ."' ");
			$row = mysqli_fetch_assoc($query);
			$_SESSION["Dept"] =$row['Dept'];
            header('location:HomeStudent.php');
		}
		else{
            echo "Invalid Credentials!<br/>";
           echo "<a href='LoginStudent.php'>Go Back</a>";
		}
	mysqli_close($con);
?>