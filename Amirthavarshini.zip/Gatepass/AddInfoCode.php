<?php
include('HeaderAlumni.php');
session_start();
?>

<?php
	include('Db.php');
	
	$query= mysqli_query($con,"Select MAX(Sno) as data From InfoTable");
	$row = mysqli_fetch_assoc($query);
	$Sno=$row['data']+1;

	$Info=$_POST["txtInfo"];
		
	$qry="Insert Into InfoTable Values('". $Sno ."','". date('Y-m-d') ."','". $_SESSION['username'] ."','". $Info ."')";
	mysqli_query($con,$qry) or die(mysqli_error());
	header('location:AddInfo.php')
?>