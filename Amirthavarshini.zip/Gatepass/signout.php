<?php
session_start();
$_SESSION['usertype']="";
session_destroy();
$_SESSION['usertype']="";
$_SESSION['username']="";
header('location:index.php');

?>